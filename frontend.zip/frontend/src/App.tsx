// src/App.tsx
import React from 'react';
import { ImageProvider } from './context/ImageContext';
import ImageUpload from './components/ImageUpload';
import ImageControls from './components/ImageControls';
import ImagePreview from './components/ImagePreview';

const App: React.FC = () => {
  return (
    <ImageProvider>
      <div>
        <h1>Image Processing App</h1>
        <ImageUpload />
        <ImageControls />
        <ImagePreview />
      </div>
    </ImageProvider>
  );
};

export default App;
