import React, { useContext } from 'react';
import { ImageContext } from '../context/ImageContext';

const ImagePreview: React.FC = () => {
    const { image } = useContext(ImageContext);

    return (
        <div>
            {image ? (
                <img src={image} alt="Processed Preview" />
            ) : (
                <p>No image uploaded yet</p>
            )}
        </div>
    );
};

export default ImagePreview;
