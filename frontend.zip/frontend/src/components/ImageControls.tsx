// src/components/ImageControls.tsx
import React from 'react';
import { useImageContext } from '../context/ImageContext';

const ImageControls: React.FC = () => {
  const { brightness, setBrightness, contrast, setContrast, saturation, setSaturation, rotation, setRotation } = useImageContext();

  return (
    <div>
      <label>
        Brightness:
        <input
          type="range"
          min="0"
          max="2"
          step="0.1"
          value={brightness}
          onChange={(e) => setBrightness(Number(e.target.value))}
        />
      </label>
      <label>
        Contrast:
        <input
          type="range"
          min="0"
          max="2"
          step="0.1"
          value={contrast}
          onChange={(e) => setContrast(Number(e.target.value))}
        />
      </label>
      <label>
        Saturation:
        <input
          type="range"
          min="0"
          max="2"
          step="0.1"
          value={saturation}
          onChange={(e) => setSaturation(Number(e.target.value))}
        />
      </label>
      <label>
        Rotation:
        <input
          type="range"
          min="0"
          max="360"
          step="1"
          value={rotation}
          onChange={(e) => setRotation(Number(e.target.value))}
        />
      </label>
    </div>
  );
};

export default ImageControls;
